<?php
// VocalIA Voice Assistant — OpenCart Language File (en-gb)
$_['heading_title']    = 'VocalIA Voice Assistant';
$_['text_edit']        = 'Edit VocalIA Module';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['entry_status']     = 'Status';
$_['entry_tenant_id']  = 'Tenant ID';
$_['help_tenant_id']   = 'Your VocalIA Tenant ID from vocalia.ma dashboard &rarr; Settings.';
$_['entry_widget_type'] = 'Widget Type';
$_['text_success']     = 'VocalIA module settings saved.';
$_['error_permission'] = 'You do not have permission to modify this module.';
